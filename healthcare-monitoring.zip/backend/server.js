const express = require("express");
const cors = require("cors");
const app = express();

app.use(cors());
app.use(express.json());

let vitals = []; // store data temporarily (no database)

app.post("/add-vitals", (req, res) => {
  vitals.push(req.body);
  res.json({ message: "Vitals added", data: req.body });
});

app.get("/get-vitals", (req, res) => {
  res.json(vitals);
});

app.listen(5000, () => console.log("✅ Server running on http://localhost:5000"));
